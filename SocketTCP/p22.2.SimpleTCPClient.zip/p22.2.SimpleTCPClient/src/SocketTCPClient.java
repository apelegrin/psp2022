import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class SocketTCPClient {

	public static void main(String[] args) {
		try {
			String serverIP ="127.0.0.1";
			int serverPort = 7878;
			String recibido;
			String comando;

			InetAddress host = InetAddress.getByName(serverIP);
			Socket s = new Socket(host,serverPort);
			
			PrintWriter flujoS = new PrintWriter(s.getOutputStream());
			InputStreamReader inTeclado = new InputStreamReader(System.in);
			BufferedReader teclado = new BufferedReader(inTeclado);
			Scanner flujoE = new Scanner(s.getInputStream());
			boolean fin = false;
			String mensa;
			while (!fin) {
				System.out.print(">");
				comando = teclado.readLine();
				flujoS.println(comando);
				flujoS.flush();
				if (comando.contains("quit")) {
					fin = true;
				}
				else {
					System.out.println();
					mensa = flujoE.nextLine();
					System.out.println(mensa);
				}
			}
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

}
