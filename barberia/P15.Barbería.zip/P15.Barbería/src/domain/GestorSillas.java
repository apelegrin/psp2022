package domain;

import java.util.concurrent.Semaphore;

public class GestorSillas {
	private final int numeroSillas;
	private boolean [] silla;
	private int [] siguienteCliente;
	
	Semaphore lock = new Semaphore(1);
	
	public GestorSillas(int numeroSillas) {
		this.numeroSillas = numeroSillas;
		this.silla = new boolean[numeroSillas];
		this.siguienteCliente = new int [numeroSillas];
		
		for (int i=0; i < numeroSillas;i++) {
			silla[i] = false;
			siguienteCliente[i] = -1;
		}
	}

	public int getSilla(int id) {
		int sillaAsignada = -1;
		//Sección crítica - entra
		try {
			lock.acquire();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		for (int i=0; i < numeroSillas;i++) {
			if (!silla[i]) {
				//cocupamos la silla
				silla[i] = true;
				sillaAsignada = i;
				esperarBarbero(id);
				break;
			}
		}
		lock.release();
		//Sección crítica - Sale
		return sillaAsignada;
	}

	private void esperarBarbero(int id) {
		for (int i=0; i < numeroSillas;i++) {
			if (siguienteCliente[i] == -1) {
				siguienteCliente[i] = id;
			}
		}
	}

	public synchronized int getSiguienteCliente() {
		//implementar siguienteCliente con una lista
		int siguiente = -1;
		for (int i=0; i < numeroSillas;i++) {
			if (siguienteCliente[i] != -1) {
				siguiente = siguienteCliente[i];
				siguienteCliente[i] = -1;
			}
		}
		return siguiente;
	}

	public void liberar(int sillaSinAtender) {
		//Terminar de liberar
		// TODO Auto-generated method stub
		
	}

}
