package main;

import domain.Barbero;
import domain.Cliente;
import domain.GestorSillas;

public class Main {

	public static void main(String[] args) {
		int MAX_BARBEROS = 2;
		int MAX_SILLAS = 3;
		int MAX_CLIENTES = 10;
		Barbero [] barbero = new Barbero[MAX_BARBEROS];
		Cliente [] cliente = new Cliente[MAX_CLIENTES];
		
		GestorSillas gestorSillas = new GestorSillas(MAX_SILLAS);
		
		//Creamos los barberos
		for (int i=0; i<MAX_BARBEROS;i++) {
			barbero[i] = new Barbero(i,gestorSillas);
		}
		
		//Creamos los clientes
		for (int i=0; i<MAX_BARBEROS;i++) {
			cliente[i] = new Cliente(i,gestorSillas);
		}
	}

}
