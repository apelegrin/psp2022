package domain;

public class Sincroniza {

}
