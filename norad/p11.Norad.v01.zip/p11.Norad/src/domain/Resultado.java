package domain;

public class Resultado {

}
