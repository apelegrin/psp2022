package domain;

import java.util.Random;

public class Ruleta  {
	private Random aleatorio = new Random();
	private int numero;
	
	public int getNumero() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
